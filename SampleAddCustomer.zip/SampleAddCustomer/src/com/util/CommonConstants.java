package com.util;

public class CommonConstants {

	
	public static final String PROPERTY_FILE = "config.properties";
	
	//public static final String TAG_NAME =  "query";

	// public static final String ATTRIB_ID = "id";

	public static final String STUDENT_ID_PREFIX = "S000";

	public static final String URL = "url";

	public static final String USERNAME ="username";

	public static final String PASSWORD = "password";

	public static final String DRIVER_NAME = "driverName";

	//public static final String QUERY_ID_DROP_TABLE ="drop_table";

	//public static final String QUERY_ID_CREATE_TABLE = "Create_Student_Table";

	//public static final String QUERY_ID_INSERT_EMPLOYEES = "Insert_Student";

	
}
